/**
 * A package containing a number of useful utility methods.
 */
package org.controlsfx.tools;